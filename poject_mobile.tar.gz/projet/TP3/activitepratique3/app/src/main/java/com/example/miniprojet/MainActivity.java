package com.example.miniprojet;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;

import java.text.BreakIterator;

public class MainActivity<isChecked> extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        View group ;


        // Obtenir une référence au bouton radio actuellement coché
//        RadioGroup rb = (RadioGroup) group.findViewById(R.id.RadioGroup1);
//        rb.getId();
        // Switch based on the 'friendly' id
        TextView editText = (TextView) findViewById(R.id.textView2);
        TextView txtValue = (TextView) findViewById(R.id.textView2);
        String editTextContents = (String) editText.getText();
        ImageView imageView = (ImageView) findViewById(R.id.imageView);
        imageView.setAlpha(.5f);
        RadioGroup radioGroup = (RadioGroup) findViewById(R.id.RadioGroup1);
        RadioButton rb1 = (RadioButton) findViewById(R.id.radioButton1);
        RadioButton rb2 = (RadioButton) findViewById(R.id.radioButton2);
        RadioButton rbnew3 = (RadioButton) findViewById(R.id.radioButton3);



        radioGroup.setOnCheckedChangeListener( new RadioGroup.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(RadioGroup group, int checkedId) {

            // Handle clicks here
                }
        } );
        radioGroup.setOnCheckedChangeListener(
                new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                // Handle clicks here
            }
        });

//        switch (rb.getId()) {
//        case R.id.radioButton1:
//        // Do something here
//            break; case R.id.radioButton2:
//        // Do something here
//                break;
//         case R.id.radioButton3:
//        // Do something here
//             break;
//         }
        // Fin du bloc switch
        CompoundButton mySwitch =  (Switch) findViewById(R.id.switch1);
        mySwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {

                txtValue.setVisibility(View.INVISIBLE);
            }else

            {
                // Currently hidden so show it
                txtValue.setVisibility(View.VISIBLE);
            }


       
    }}
    );
        CompoundButton myCheckBox=(CheckBox) findViewById(R.id.checkBox);;
        myCheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged( CompoundButton buttonView, boolean isChecked) {
                if (myCheckBox.isChecked()) {
                    // It's checked so do something
                }else {

                }
            }});
        WebView webView = (WebView) findViewById(R.id.WebView);
        webView.loadUrl("http://google.com");

}
    
}