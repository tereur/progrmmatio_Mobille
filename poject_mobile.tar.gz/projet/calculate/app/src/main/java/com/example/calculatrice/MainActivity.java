package com.example.calculatrice;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android. widget.*;

public class MainActivity extends AppCompatActivity {

    //On déclare toutes les variables dont on aura besoin
    Button button0;
    Button button1;
    Button button2;
    Button button3;
    Button button4;
    Button button5;
    Button button6;
    Button button7;
    Button button8;
    Button button9;
    Button buttonPlus;
    Button buttonMoins;
    Button buttonDiv;
    Button buttondel;
    Button buttonMul;
    Button buttonC;
    Button buttonEgal;
    Button buttonPoint;
    TextView ecran;
    TextView ecran1;

    private double chiffre1;
    private double chiffre2;
    private boolean clicOperateur = false;
    private boolean update = false;
    private String operateur = "";
    private boolean oper = false;
    private boolean operation =false;
    private boolean nombre =false;
   public static int nbrpoint=0;
    private boolean egale =true;
    int j=0;
    static double[] tab=new double[2];
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //On récupère tous les éléments de notre interface graphique grâce aux ID
        button0 = (Button) findViewById (R. id.button0);
        button1 = (Button) findViewById (R. id.button1);
        button2 = (Button) findViewById (R. id.button2);
        button3 = (Button) findViewById (R.id.button3);
        button4 = (Button) findViewById(R.id.button4);
        button5 = (Button) findViewById(R.id.button5);
        button6 = (Button) findViewById(R.id.button6);
        button7 = (Button) findViewById(R.id.button7);
        button8 = (Button) findViewById(R.id.button8);
        button9 = (Button) findViewById(R.id.button9);
        buttonPoint = (Button) findViewById(R.id.buttonPoint);
        buttonPlus = (Button) findViewById(R.id.buttonPlus);
        buttonMoins = (Button) findViewById(R.id.buttonMoins);
        buttonDiv = (Button) findViewById(R.id.buttonDiv);
        buttondel = (Button) findViewById(R.id.buttondel);
        buttonMul = (Button) findViewById(R.id.buttonMul);
        buttonC = (Button) findViewById(R.id.buttonC);
        buttonEgal = (Button) findViewById(R.id.buttonEgal);
        ecran1 = (TextView) findViewById(R.id.text2);
        ecran = (TextView) findViewById(R.id.text1);

        // on attribue un ecouteur d evenement


        //On attribue un écouteur d’évènement à tous les boutons

        buttonPlus. setOnClickListener (new View.OnClickListener() {
            public void onClick(View v) {
                if(nombre) {
                    oper=true;
                    plusClick();
                    nbrpoint = 0;
                    chiffreClick("+");
                    nombre = false;


                }else{
                    return;
                }
            }
        });

        buttonMoins. setOnClickListener (new View.OnClickListener() {
            public void onClick(View v) {
                if(nombre) {
                    oper=true;
                    moinsClick();
                    nbrpoint = 0;
                    chiffreClick("-");
                    nombre = false;

                }else{
                    return;
                }
            }
        });

        buttonDiv. setOnClickListener (new View.OnClickListener() {
            public void onClick(View v) {
                if(nombre) {
                    oper=true;
                    divClick();
                    nbrpoint = 0;
                    chiffreClick("/");
                    nombre = false;

                }else{
                    return;
                }
            }
        });

        buttonMul. setOnClickListener (new View.OnClickListener() {
            public void onClick(View v) {
                if(nombre) {
                    oper=true;
                    mulClick();
                    nbrpoint = 0;
                    chiffreClick("*");
                    nombre = false;

                }else{
                    return;
                }
            }
        });

        buttonC. setOnClickListener (new View.OnClickListener() {
            public void onClick(View v) {
                resetClick();
                nbrpoint=0;
                nombre=false;
                taille();
            }
        });

        buttonEgal. setOnClickListener (new View.OnClickListener() {
            public void onClick(View v) {
                egalClick();
                nbrpoint=0;
                taille();
                operation = true;
                egale=false;

            }
        });

        buttonPoint. setOnClickListener (new View.OnClickListener() {
            public void onClick(View v) {
                if(nbrpoint ==1) {
                    return;
                }else{
                String mot = (String) ecran.getText();
                String mot1 = "";
                for (int i = 0; i < mot.length(); i++)
                    mot1 = "" + mot.charAt(i);


                if(!nombre){
                    nbrpoint = 1;
                    chiffreClick("0.");
                    chiffreClick1("0.");
                    nombre = false;
                }else {
                    nbrpoint = 1;
                    chiffreClick(".");
                    chiffreClick1(".");
                    nombre = false;
               }}

            }
        });

        button0.setOnClickListener (new View.OnClickListener() {
            public void onClick(View v) {
                chiffreClick("0");
                chiffreClick1("0");


            }
        });

        button1.setOnClickListener (new View.OnClickListener() {
            public void onClick(View v) {
                chiffreClick("1");
                chiffreClick1("1");

            }
        });

        button2.setOnClickListener (new View.OnClickListener() {
            public void onClick(View v) {
                chiffreClick("2");
                chiffreClick1("2");


            }
        });

        button3.setOnClickListener (new View.OnClickListener() {
            public void onClick(View v) {

                chiffreClick("3");
                chiffreClick1("3");

            }
        });

        button4.setOnClickListener (new View.OnClickListener() {
            public void onClick(View v) {
                chiffreClick("4");
                chiffreClick1("4");

            }
        });

        button5.setOnClickListener (new View.OnClickListener() {
            public void onClick(View v) {
                chiffreClick("5");
                chiffreClick1("5");

            }
        });

        button6.setOnClickListener (new View.OnClickListener() {
            public void onClick(View v) {
                chiffreClick("6");
                chiffreClick1("6");

            }
        });

        button7.setOnClickListener (new View.OnClickListener() {
            public void onClick(View v) {
                chiffreClick("7");
                chiffreClick1("7");

            }
        });

        button8.setOnClickListener (new View.OnClickListener() {
            public void onClick(View v) {
                chiffreClick("8");
                chiffreClick1("8");
            }
        });

        button9.setOnClickListener (new View.OnClickListener() {
            public void onClick(View v) {
                chiffreClick("9");
                chiffreClick1("9");
            }
        });
        buttondel.setOnClickListener (new View.OnClickListener() {
            public void onClick(View v) {
                delClick();
            }
        });

    }
     // voici la methode pour reduire la taille du text
    public void taille(){
        if((ecran.getText()).length()>=10)
            ecran.setTextSize(24F);
         else
            ecran.setTextSize(34F);
    }
    //voici la méthode qui est exécutée lorsqu’on clique sur un bouton chiffre
    public void chiffreClick (String str) {
        operation=false;
        if(! ecran1. getText (). equals ("0") && egale || (!egale && oper))
                str = ecran.getText() + str;

        ecran. setText (str);
           nombre=true;
        taille();
        egale=true;

    }
    public void chiffreClick1 (String str) {
        if(update){
            update = false;
        }else{
            if(! ecran1. getText (). equals ("0") && egale || (!egale && oper))
                str = ecran1.getText() + str;
            oper=false;
        }
        ecran1. setText (str);
        nombre=true;
        taille();
        ecran1.setVisibility(View. INVISIBLE);
        egale=true;
//        new Timer().schedule(new TimerTask() {
//            @Override
//            public void run() {
//               calcul();
//            }
//        }, 300L);
}




    //voici la méthode qui est  exécutée lorsqu’on clique sur le bouton +
    public void plusClick() {

        if(clicOperateur){
            calcul ();
            ecran1. setText (String.valueOf(chiffre1));
        }else{
            chiffre1 = Double.valueOf(ecran1.getText().toString()).doubleValue();
            clicOperateur = true;
        }
        operateur = "+";
        update = true;
    }
    //voici la méthode qui est  exécutée lorsqu’on clique sur le bouton D
    public void delClick(){
        if(!operation) {
            String del = (String) ecran.getText();
            String del1 = "";
            for (int i = 0; i < del.length() - 1; i++)
                del1 = del1 + del.charAt(i);
            ecran.setText(del1);
            ecran1.setText(del1);
            char mot=del.charAt(del.length()-1);
            if(mot=='+' || mot=='*' || mot=='/' || mot=='-') {
                nombre = true;
                update=false;
                clicOperateur=false;
            }else{
                nombre=false;
            }
        }else{
            resetClick();
        }

    }

    //voici la méthode qui est  exécutée lorsqu’on clique sur le bouton -
    public void moinsClick() {
        if(clicOperateur){
            calcul ();
            ecran1.setText(String.valueOf (chiffre1));
        }else{
            chiffre1 = Double.valueOf(ecran1.getText().toString()).doubleValue();
            clicOperateur = true;
        }
        operateur = "-";
        update = true;
    }

    //voici la méthode qui est  exécutée lorsqu’on clique sur le bouton *
    public void mulClick() {
        if(clicOperateur){
            calcul ();
            ecran1.setText(String.valueOf (chiffre1));
        }else{
            chiffre1 = Double.valueOf(ecran1.getText().toString()).doubleValue();
            clicOperateur = true;
        }
        operateur = "*";
        update = true;
    }
    //voici la méthode qui est  exécutée lorsqu’on clique sur le bouton /
    public void divClick(){
        if(clicOperateur){
            calcul ();
            ecran1.setText(String.valueOf (chiffre1));
        }else{
            chiffre1 = Double.valueOf(ecran1.getText().toString()).doubleValue();
            clicOperateur = true;
        }
        operateur = "/";
        update = true;
    }
    //voici la méthode qui est  exécutée lorsqu’on clique sur le bouton =
    public void egalClick() {
        calcul ();
        update = true;
        clicOperateur = false;

    }

    //voici la méthode qui est  exécutée lorsque l’on clique sur le bouton C
    public void resetClick() {
        clicOperateur = false;
        update = true;
        chiffre1 = 0;
        operateur = "";
        ecran. setText ("");
        ecran1. setText ("");
    }


    
    //Voici la méthode qui fait le calcul qui a été demandé par l’utilisateur
    private void calcul () {
        if (operateur. equals ("+")) { chiffre1 = chiffre1 + Double.valueOf (ecran1. getText (). toString ()). doubleValue();
            ecran1.setText(String.valueOf (chiffre1));
            ecran.setText(String.valueOf (chiffre1));
            operateur="";
            ecran1.setVisibility(View. VISIBLE);
        }

        if(operateur. equals ("-")){
            chiffre1 = chiffre1 - Double.valueOf (ecran1. getText (). toString ()). doubleValue();
            ecran1.setText(String.valueOf (chiffre1));
            ecran.setText(String.valueOf (chiffre1));
            operateur="";
            ecran1.setVisibility(View. VISIBLE);
        }

        if(operateur. equals ("*")){
            chiffre1 = chiffre1 * Double.valueOf (ecran1. getText (). toString ()). doubleValue();
            ecran1.setText(String.valueOf (chiffre1));
            ecran.setText(String.valueOf (chiffre1));
            operateur="";
            ecran1.setVisibility(View. VISIBLE);
        }

        if(operateur.equals("/")){
            try{
                chiffre1 = chiffre1 / Double.valueOf(ecran1.getText().toString()).doubleValue();
                ecran1.setText(String.valueOf(chiffre1));
                ecran.setText(String.valueOf(chiffre1));
                operateur="";
                ecran1.setVisibility(View. VISIBLE);
            }catch(ArithmeticException e){
                ecran1. setText ("error");
                ecran1.setVisibility(View. VISIBLE);
            }
        }
    }

    }
